//***************************************************************************
//* TempNTC.C
//*--------------------------------------------------------------------------
//* Temperature conversion routines
//*--------------------------------------------------------------------------
//* (c) Beamspot Guillem Planissi. 2008 March. Release 1.0. English
//***************************************************************************
/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (took from Mr J�rg Wunsch):
 * Guillem Planissi/Beamspot wrote this file.  As long as you retain this 
 * notice you can do whatever you want with this stuff. If we meet some day, and 
 * you think this stuff is worth it, you can buy me a beer in return.    Guillem
 * ----------------------------------------------------------------------------
 *
 * This software is served "as is", and there is no any warranty about it,
 * neither for the results of its use. Use it at your own Risk.
 */

#include "TempNTC.h"

//** NTC Linealization table
#ifdef __IAR_SYSTEMS_ICC__
__flash 
#endif 
const unsigned int ADCTable[TablePoints]=
{939, 892, 828, 749, 657, 560, 464, 377, 300, 237, 186};
//-30,-20, -10,  0,   10,  20,  30,  40,  50,  60,  70 �C
//  0   1    2   3     4    5    6    7    8    9   10  i

//***************************************************************************
//*  Function TempNTC
//*  Returns temperature value converted by means of interpolation
//*  ADC is the ADC result
//*  To is temperature blealue for index 0 from the table (-30�C)
//*  dT is temperature difference between two entries in the tabel (10�C)
//***************************************************************************
int TempNTC(unsigned int adc, int To, int dT)
{
  int aux;
  unsigned int min, max;
  unsigned char i;
  
  //Search the interval where adc value fits
  for(i=0;(i<TablePoints)&&(adc<(ADCTable[i])); i++);
  if ((i==0)||(i==TablePoints)) //If we don't find it, return error
    return -32767;
  max=ADCTable[i-1]; //Took the highest value of the interval
  min=ADCTable[i];   //and the smallest
  aux=(max-adc)*dT;  //first step of the interpolation
  aux=aux/(max-min); //and second step
  aux+=(i-1)*dT+To;  //and we add the offset
  return aux;
}
//************************ The End *******************************************
