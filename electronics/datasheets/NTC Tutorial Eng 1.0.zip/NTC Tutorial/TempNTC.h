//***************************************************************************
//* TempNTC.h
//*--------------------------------------------------------------------------
//* Declarations and macros for temperature conversion
//*--------------------------------------------------------------------------
//* (c) Beamspot Guillem Planissi. 2008 March. Release 1.0. English
//***************************************************************************

//Avoid any duplicate definitions
#ifndef _TempNTC_H
#define _TempNTC_H

//Constants for conversion
#define TablePoints   (11)
//Conversion to �Celsius
#define ToCels      (-300)
#define dTCels       (100)
//Conversion to Kelvins
#define ToKelv      (2430)
#define dTKelv       (100)
//Conversion to �Fahrenheit
#define ToFahr      (-220)
#define dTFahr       (180)

//Prototipes for public functions
int TempNTC(unsigned int adc, int To, int dT);

#endif
