//***************************************************************************
//* hard.C
//*--------------------------------------------------------------------------
//* Hardware control routines
//*--------------------------------------------------------------------------
//* (c) Beamspot Guillem Planissi. 2008 March. Release 1.0. English
//***************************************************************************
/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (took from Mr J�rg Wunsch):
 * Guillem Planissi/Beamspot wrote this file.  As long as you retain this 
 * notice you can do whatever you want with this stuff. If we meet some day, and 
 * you think this stuff is worth it, you can buy me a beer in return.    Guillem
 * ----------------------------------------------------------------------------
 *
 * This software is served "as is", and there is no any warranty about it,
 * neither for the results of its use. Use it at your own Risk.
 */

#include "hard.h"

#ifdef __IAR_SYSTEMS_ICC__
  #include <iom64.h>
  #include <intrinsics.h>

  #pragma vector=ADC_vect
  __interrupt void ISR_ADC(void);
#else
  #include <ctype.h>
  #include <stdint.h>
  #include <stdio.h>

  #include <avr/eeprom.h>
  #include <avr/interrupt.h>
  #include <avr/io.h>
  #include <avr/pgmspace.h>
  #include <avr/sleep.h>
  #include <avr/wdt.h>
#endif

volatile unsigned int ADCBuff[ADCBuffLon];
volatile unsigned char AdcIn;

//***************************************************
//** Ports Initialization
void InitPorts(void)
{
 PORTA = 0x30;
 DDRA  = 0xDF; //
 PORTB = 0x00;
 DDRB  = 0x1C; //
 PORTC = 0x66; //
 DDRC  = 0x0C; //
 PORTD = 0x06;
 DDRD  = 0x18; //
 PORTE = 0x00;
 DDRE  = 0xF8; //
 PORTF = 0x00;
 DDRF  = 0x00; //Analog inputs
 PORTG = 0x00;
 DDRG  = 0x04; //
}

//******************************************************************************
//** ADC Initialization
//**
void initadc(void)
{
 ADCSRA = (1<<ADEN)|(1<<ADIF); //Stop ADC and clear any IRQ flag
 ADMUX  = (1<<REFS0)|(ADCChannel<<MUX0); //select ref=AVCC & AMUX NTC input
 ACSR   = ACSR & ~(1<<ACIE); //Clean any pending IRQ flag from AC
 ACSR   = (1<<ACD); //Stop AC
 ADCSRB = 0x00; //Stop Autotrigger
 ADCSRA = (1<<ADEN)|(1<<ADIE)|(7<<ADPS0); //Active ADC, Interrupt Enabled & Prescaler at 128
}

//***************************************************
//** Conversion complete ISR
//** Reads Result and stores it into buffer
#ifdef __IAR_SYSTEMS_ICC__
  #pragma vector=ADC_vect
  __interrupt void ISR_ADC(void)
#else
ISR(ADC_vect)
#endif
{
  ADCBuff[AdcIn++]=ADC;
  if (AdcIn==ADCBuffLon)
    AdcIn=0;
  StartADC();//Restart conversion
}

//***************************************************
//** Peripheral initalization
void Init(void)
{
 __disable_interrupt(); //disable all interrupts
 InitPorts();
 initadc();
 
 XDIV  = 0x00; //maximum clock speed (8MHz)
 XMCRA = 0x00; //no external memory

 SFIOR = 0x08; //Enable Mux use by AC
 MCUCR = 0x00; //Init MCU
 EICRA = 0x02; //and external IRQ sources
 EICRB = 0x00;
 EIMSK = 0x00;
 TIMSK = 0xA6; //Timer 1 Ovf & Cap, Timer 0 Compare match, Timer 2 Ovf.
 ETIMSK = 0x00; //

 OSCCAL = 0xAE; //Internal clock calibration by factory values
 __enable_interrupt(); //re-enable interrupts
}
