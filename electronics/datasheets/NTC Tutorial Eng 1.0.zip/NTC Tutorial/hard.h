//***************************************************************************
//* hard.h
//*--------------------------------------------------------------------------
//* Hardware control declarations.
//*--------------------------------------------------------------------------
//* (c) Beamspot Guillem Planissi. 2008 March. Release 1.0. English
//***************************************************************************

//Avoid any duplicate definitions
#ifndef _hard_H
#define _hard_H

//Macro definitions
#define StartADC() ADCSRA |=(1<<ADSC)
#define ADCChannel  (0)
#define ADCBuffLon (34)

#ifndef __IAR_SYSTEMS_ICC__
 #define __disable_interrupt() cli()
 #define __enable_interrupt()  sei()
#endif

//Prototipes for public functions
void InitPorts(void);
void initadc(void);
void Init(void);

#endif
