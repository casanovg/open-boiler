//***************************************************************************
//* main.C
//*--------------------------------------------------------------------------
//* Programa principal
//*--------------------------------------------------------------------------
//* (c) Beamspot Guillem Planissi. 2008 March. Release 1.0. English
//***************************************************************************
/*
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (took from Mr J�rg Wunsch):
 * Guillem Planissi/Beamspot wrote this file.  As long as you retain this 
 * notice you can do whatever you want with this stuff. If we meet some day, and 
 * you think this stuff is worth it, you can buy me a beer in return.    Guillem
 * ----------------------------------------------------------------------------
 *
 * This software is served "as is", and there is no any warranty about it,
 * neither for the results of its use. Use it at your own Risk.
 */
#ifdef __IAR_SYSTEMS_ICC__
  #include <iom64.h>
  #include <intrinsics.h>
#else
  #include <avr/io.h>
#endif

#include "hard.h"
#include "TempNTC.h"

//External variable definition
extern volatile unsigned int ADCBuff[ADCBuffLon];
extern volatile unsigned char AdcIn;
extern const unsigned int ADCTable[TablePoints];

//Global variables definition
signed int Temp;

//Filtering parameters definiton
#define FIRSum   (11872)
#define IRVal       (50)
#define FIRLen      (31)
//FIR filter Kernel
#ifdef __IAR_SYSTEMS_ICC__
__flash 
#endif 
const unsigned int FIR[FIRLen]={
1, 3, 9, 23, 48, 89, 149, 230, 333, 454, 586, 719, 840, 938, 1002, 1024,
1002, 938, 840, 719, 586, 454, 333, 230, 149, 89, 48, 23, 9, 3, 1};

//Prototipes for Filtering functions declaration
unsigned int Average(void);
unsigned int RobustAverage(void);
unsigned int MovingAverage(unsigned char start);
unsigned int FirFilter(unsigned char start);
unsigned int IirFilter(unsigned int value);

//********** Main Program ***************
int main( void )
{
  unsigned char Old=0;
  
  Init();  //Inicializamos el hardware
  StartADC();  //Ponemos en marcha el conversor ADC
    for(;;)
    {
      
      //...
      
        Temp=TempNTC(ADCBuff[Old],ToCels,dTCels);//Direct value conversion
        //Temp=TempNTC(Average(),ToCels,dTCels);//Conversion of the mean value;
        //Temp=TempNTC(FirFilter(Old),ToCels,dTCels);//Conversion of an FIR filtered value
        //Temp=TempNTC(IirFilter(ADCBuff[Old]),ToCels,dTCels);//Conversion of an IIR filtered value
        Old=AdcIn;
      //...
    }
}

//*********************************************************************
//** Averaging function
unsigned int Average(void)
{
  unsigned char i;
  unsigned int aux=0;
  
  for (i=0;i<ADCBuffLon;i++)
     aux+=ADCBuff[i];
  aux=aux/ADCBuffLon;
  return aux;
}

//*********************************************************************
//** Robust averaging function
unsigned int RobustAverage(void)
{
  unsigned char i;
  unsigned int aux, max, min;
  
  aux=max=min=ADCBuff[0];
  for (i=1;i<ADCBuffLon;i++)
  {
    aux+=ADCBuff[i];
    if (ADCBuff[i]>max)
      max=ADCBuff[i];
    else if (ADCBuff[i]<min)
      min=ADCBuff[i];
  }
  aux-=max;
  aux-=min;
  aux=aux>>5;
  return aux;
}

//*********************************************************************
//** Moving Average function
unsigned int MovingAverage(unsigned char start)
{
  static unsigned int acumulator;
  
  acumulator+=ADCBuff[start];
  if (start==(ADCBuffLon-1))
    acumulator-=ADCBuff[0];
  else
    acumulator-=ADCBuff[start+1];
  return acumulator/ADCBuffLon;
}

//*********************************************************************
//** FIR Filtering function
unsigned int FirFilter(unsigned char start)
{
  unsigned char i;
  unsigned long int aux=0;
  unsigned int res;
  
  for(i=0;i<FIRLen;i++)
  {
    aux+=(unsigned long)(ADCBuff[start++])*(unsigned long)(FIR[i]);
    if (start==ADCBuffLon)
      start=0;
  }
  res=((unsigned long int)(aux))/((unsigned long int)(FIRSum));
  return res;
}

//*********************************************************************
//** IIR filtering function
unsigned int IirFilter(unsigned int value)
{
  static unsigned int Y;
  
  Y=(64-IRVal)*value + IRVal*Y;
  Y=(Y>>6);
  return Y;
}
//*************************** The End ********************************
