//***************************************************************************
//* hard.C
//*--------------------------------------------------------------------------
//* Rutinas de control del hardware. 'Drivers'
//*--------------------------------------------------------------------------
//* (c) Beamspot. Marzo 2008. Versi�n 1.0
//***************************************************************************
/*
Licencia cervecera.
Cualquiera es libre de usar este programa cuando y como le plazca. Si alg�n dia
nos encontramos, y esto le ha sido de utilidad, siempre me puede invitar a una
cerveza u otra bebida que nos venga a gusto. ;)

Declino cualquier responsabilidad sobre el uso de dicho programa. No doy ninguna
garant�a respecto del correcto funcionamiento y/o compilaci�n.

Este programa ha sido compilado con IAR 5.10 para AVR y con WinAVR/AVRStudio,
y probado sobre un ATmega64.
*/

#include "hard.h"

#ifdef __IAR_SYSTEMS_ICC__
  #include <iom64.h>
  #include <intrinsics.h>

  #pragma vector=ADC_vect
  __interrupt void ISR_ADC(void);
#else
  #include <ctype.h>
  #include <stdint.h>
  #include <stdio.h>

  #include <avr/eeprom.h>
  #include <avr/interrupt.h>
  #include <avr/io.h>
  #include <avr/pgmspace.h>
  #include <avr/sleep.h>
  #include <avr/wdt.h>
#endif

volatile unsigned int ADCBuff[ADCBuffLar];
volatile unsigned char AdcIn;

//***************************************************
//** Inicialitzam es ports d'es micro
void InitPorts(void)
{
 PORTA = 0x30;
 DDRA  = 0xDF; //
 PORTB = 0x00;
 DDRB  = 0x1C; //
 PORTC = 0x66; //
 DDRC  = 0x0C; //
 PORTD = 0x06;
 DDRD  = 0x18; //
 PORTE = 0x00;
 DDRE  = 0xF8; //
 PORTF = 0x00;
 DDRF  = 0x00; //Entradas anal�gicas: temp ext
 PORTG = 0x00;
 DDRG  = 0x04; //
}

//******************************************************************************
//** Inicializaci�n del conversor ADC
//**
void initadc(void)
{
 ADCSRA = (1<<ADEN)|(1<<ADIF); //Paramos el ADC y 'limpiamos' el flag de IRQ
 ADMUX  = (1<<REFS0)|(CanalADC<<MUX0);//0x41; //seleccionamos ref=AVCC i AMUX entrada termistor
 ACSR   = ACSR & ~(1<<ACIE); //'limpiamos' el flag de IRQ del comparador anal�gico
 ACSR   = (1<<ACD); //Paramos el comparador anal�gico
 ADCSRB = 0x00; //Deshabilitamos el Autotrigger
 ADCSRA = (1<<ADEN)|(1<<ADIE)|(7<<ADPS0); //Activo, Interrupt Enabled i Prescaler a 128
}

//***************************************************
//** ISR de fin de conversi�n del ADC
//** Recoge el resultado y lo pone en el buffer
#ifdef __IAR_SYSTEMS_ICC__
  #pragma vector=ADC_vect
  __interrupt void ISR_ADC(void)
#else
ISR(ADC_vect)
#endif
{
  ADCBuff[AdcIn++]=ADC;
  if (AdcIn==34)
    AdcIn=0;
  //ArrancaADC();//ADCSRA|=(1<<ADSC);//recomen�am conversi�
}

//***************************************************
//** Inicializamos los perif�ricos
void Inicializa(void)
{
 __disable_interrupt(); //disable all interrupts
 InitPorts();
 initadc();
 
 XDIV  = 0x00; //rellotge a m�xima velocitat (peupost)
 XMCRA = 0x00; //sense mem�ria externa

 SFIOR = 0x08; //Habilitam s'us d'es AMUX a n'es comparador
 MCUCR = 0x00; //finalment inicialtzam sa CPU
 EICRA = 0x02; //i ses seves interrupcions
 EICRB = 0x00;
 EIMSK = 0x00;
 TIMSK = 0xA6; //Timer 1 Ovf i Cap, Timer 0 Compare match, Timer 2 Ovf.
 ETIMSK = 0x00; //

 OSCCAL = 0xAE; //Calibraci� d'es rellotge intern segons Atmel/AVRStudio 8MHz
 __enable_interrupt(); //re-enable interrupts
}
