//***************************************************************************
//* hard.h
//*--------------------------------------------------------------------------
//* Declaraciones de la interfaz de hardware. 'Drivers'
//*--------------------------------------------------------------------------
//* (c) Beamspot. Marzo 2008. Versi�n 1.0
//***************************************************************************

//Mecanismo 'antiduplicidad'
#ifndef _hard_H
#define _hard_H

//Definici�n de macros �tiles
#define ArrancaADC() ADCSRA |=(1<<ADSC)
#define CanalADC    (0)
#define ADCBuffLar (34)

#ifndef __IAR_SYSTEMS_ICC__
 #define __disable_interrupt() cli()
 #define __enable_interrupt()  sei()
#endif

//Prototipos de funciones a exportar del m�dulo
void InitPorts(void);
void initadc(void);
void Inicializa(void);

#endif
