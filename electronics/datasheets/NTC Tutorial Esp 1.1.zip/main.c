//***************************************************************************
//* main.C
//*--------------------------------------------------------------------------
//* Programa principal
//*--------------------------------------------------------------------------
//* (c) Beamspot. Marzo 2008. Versi�n 1.0
//***************************************************************************
/*
Licencia cervecera.
Cualquiera es libre de usar este programa cuando y como le plazca. Si alg�n dia
nos encontramos, y esto le ha sido de utilidad, siempre me puede invitar a una
cerveza u otra bebida que nos venga a gusto.;)

Declino cualquier responsabilidad sobre el uso de dicho programa. No doy ninguna
garant�a respecto del correcto funcionamiento y/o compilaci�n.

Este programa ha sido compilado con IAR 5.10 para AVR y con WinAVR/AVRStudio,
y probado sobre un ATmega64.
*/
#ifdef __IAR_SYSTEMS_ICC__
  #include <iom64.h>
  #include <intrinsics.h>
#else
  #include <avr/io.h>
#endif

#include "hard.h"
#include "TempNTC.h"

//Definici�n de variables externas
extern volatile unsigned int ADCBuff[ADCBuffLar];
extern volatile unsigned char AdcIn;
extern const unsigned int TablaADC[PuntosTabla];

//Definici�n de variables globales
signed int Temp;

//Definiciones de pr�metros para el filtrado
#define FIRSum   (11872)
#define IRVal       (50)
#define FIRLen      (31)
//N�cleo de un filtro pasabajos
#ifdef __IAR_SYSTEMS_ICC__
__flash 
#endif 
const unsigned int FIR[FIRLen]={
1, 3, 9, 23, 48, 89, 149, 230, 333, 454, 586, 719, 840, 938, 1002, 1024,
1002, 938, 840, 719, 586, 454, 333, 230, 149, 89, 48, 23, 9, 3, 1};

//Prototipos de funciones de filtrado
unsigned int Media(void);
unsigned int MediaRobusta(void);
unsigned int MediaMovil(unsigned char inicio);
unsigned int FiltroFir(unsigned char inicio);
unsigned int FiltroIir(unsigned int valor);

//********** Programa principal ***************
int main( void )
{
  unsigned char Anterior=0;
  
  Inicializa();  //Inicializamos el hardware
  ArrancaADC();  //Ponemos en marcha el conversor ADC
    for(;;)
    {
      
      //...
      
        Temp=TempNTC(ADCBuff[Anterior],ToCels,dTCels);//Hacemos la conversi�n del valor directo
        //Temp=TempNTC(Media(),ToCels,dTCels);//Hacemos la conversi�n de la media;
        //Temp=TempNTC(FiltroFir(Anterior),ToCels,dTCels);//Conversi�n de un filtro FIR
        //Temp=TempNTC(FiltroIir(ADCBuff[Anterior]),ToCels,dTCels);//Conversi�n de un filtro IIR
        Anterior=AdcIn;
      //...
    }
}

//*********************************************************************
//** Funci�n que hace la media de las medidas contenidas en el buffer
unsigned int Media(void)
{
  unsigned char i;
  unsigned int aux=0;
  
  for (i=0;i<ADCBuffLar;i++)
     aux+=ADCBuff[i];
  aux=aux/ADCBuffLar;
  return aux;
}

//*********************************************************************
//** Funci�n que hace la media de las medidas contenidas en el buffer
unsigned int MediaRobusta(void)
{
  unsigned char i;
  unsigned int aux, max, min;
  
  aux=max=min=ADCBuff[0];
  for (i=1;i<ADCBuffLar;i++)
  {
    aux+=ADCBuff[i];
    if (ADCBuff[i]>max)
      max=ADCBuff[i];
    else if (ADCBuff[i]<min)
      min=ADCBuff[i];
  }
  aux-=max;
  aux-=min;
  aux=aux>>5;
  return aux;
}

//*********************************************************************
//** Funci�n que hace la media de las medidas contenidas en el buffer
unsigned int MediaMovil(unsigned char inicio)
{
  static unsigned int acumulador;
  
  acumulador+=ADCBuff[inicio];
  if (inicio==(ADCBuffLar-1))
    acumulador-=ADCBuff[0];
  else
    acumulador-=ADCBuff[inicio+1];
  return acumulador/ADCBuffLar;
}

//*********************************************************************
//** Funci�n que hace la media de las medidas contenidas en el buffer
unsigned int FiltroFir(unsigned char inicio)
{
  unsigned char i;
  unsigned long int aux=0;
  unsigned int res;
  
  for(i=0;i<FIRLen;i++)
  {
    aux+=(unsigned long)(ADCBuff[inicio++])*(unsigned long)(FIR[i]);
    if (inicio==ADCBuffLar)
      inicio=0;
  }
  res=((unsigned long int)(aux))/((unsigned long int)(FIRSum));
  return res;
}

//*********************************************************************
//** Funci�n que hace la media de las medidas contenidas en el buffer
unsigned int FiltroIir(unsigned int valor)
{
  static unsigned int Y;
  
  Y=(64-IRVal)*valor + IRVal*Y;
  Y=(Y>>6);
  return Y;
}
